"""Provider abstraction layer."""
