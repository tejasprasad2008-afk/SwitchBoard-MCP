"""Tests for switchboard router."""
